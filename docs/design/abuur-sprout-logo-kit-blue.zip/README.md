# ABUUR Digital: sprout logo kit (blue)

The sprout mark (two leaves, a stem and a gem), in ABUUR brand blue, with 3D and flat versions.
All SVGs are pure vector shapes: the "ABUUR DIGITAL" text is converted to outlines, so no font is needed.

## Colours

| Name | Hex | Use |
|---|---|---|
| ABUUR Blue | `#0D6EFD` | Main colour: tile, leaves on light backgrounds, "DIGITAL" |
| Bright Blue | `#4A95FF` | Top of gradients, highlights |
| Deep Blue | `#0646C4` | Bottom of gradients |
| Ink Blue | `#0A2E7A` | Gem on light backgrounds |
| Ice Blue | `#C9DCFF` | Gem on blue backgrounds |
| Sky Blue | `#7FB0FF` | "DIGITAL" on dark backgrounds |
| White | `#FFFFFF` | Leaves and text on blue/dark backgrounds |

"ABUUR" on light backgrounds uses a blue gradient (`#1F7BFF` → `#0838B8`).
Wordmark font: Inter ExtraBold ("ABUUR") and Inter SemiBold, letter-spaced ("DIGITAL"). Inter is free (SIL Open Font License).

## What to use where

| You need | Use |
|---|---|
| App icon / store icon | `png/app-icons/app-icon-1024.png` (3D blue tile) |
| Website header, light background | `svg/logos/logo-horizontal-light.svg` (flat) or `logo-horizontal-3d-light.svg` |
| Website header, dark background | `svg/logos/logo-horizontal-dark.svg` |
| Big, eye-catching logo (landing page, posters, slides) | `logo-horizontal-3d-tile-*` or `logo-stacked-3d-tile-*` |
| Browser tab icon | `favicon/favicon.ico`, `favicon/favicon.svg` |
| iPhone home screen | `favicon/apple-touch-icon.png` (180 × 180) |
| Android / PWA | `png/app-icons/app-icon-192.png`, `app-icon-512.png` |
| Social media profile picture | `png/icons/icon-3d-1024.png` |
| Link preview (Facebook, WhatsApp, X) | `png/social/og-image-1200x630.png` |
| One-colour printing, stamps, embroidery | `mark-mono-blue` / `mark-mono-white` |

`-light` files are for white or light backgrounds (blue text). `-dark` files are for dark or blue backgrounds (white text).

## Folders

- `svg/icons/`:
  - `icon-3d`: glossy blue tile with a white 3D sprout.
  - `icon-3d-mark-blue`: 3D blue sprout, transparent, for light backgrounds.
  - `icon-3d-mark-white`: 3D white sprout, transparent, for dark backgrounds.
  - `icon-flat-blue`, `icon-flat-rounded`: flat sprout on a square or rounded blue tile.
  - `mark-blue`, `mark-white`, `mark-mono-*`: flat sprout alone.
- `svg/logos/`: horizontal and stacked logos (3D tile, 3D, flat; light and dark) and the wordmark alone.
- `png/icons/`: every icon at 256, 512 and 1024 px.
- `png/logos/`: every logo at 800, 1600 and 3200 px wide (transparent background).
- `png/app-icons/`: 16 to 1024 px. Sizes 16–64 use the flat icon so they stay sharp.
- `favicon/`: `favicon.ico` (16, 32, 48), `favicon.svg`, `favicon-32.png`, `apple-touch-icon.png`.

## Website snippet

```html
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<meta property="og:image" content="/og-image-1200x630.png">
```

## Spacing

Keep clear space around the logo at least the height of the gem, and don't stretch, recolour or rotate it.
